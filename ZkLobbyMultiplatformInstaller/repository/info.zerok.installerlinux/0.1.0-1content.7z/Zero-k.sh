#!/bin/sh
mono Zero-K
